
clear all;
close all;
clc;

if (exist('DATABASE.mat','file'))
    load DATABASE.mat;
end
while (1==1)
    choice=menu('Face Recognition',...
                'Generate Database',...
                'Calculate Recognition Rate',...
                'Recognize from Image',...
                'Exit');
    if (choice ==1)
        if (~exist('DATABASE.mat','file'))
            [myDatabase,minmax] = gendatabase();        
        else
            pause(0.1);    
            choice2 = questdlg('Generating a new database will remove previous trained database. Are you sure?', ...
                               'Warning...',...
                               'Yes', ...
                               'No','No');            
            switch choice2
                case 'Yes'
                    pause(0.1);
                    [myDatabase minmax] = gendatabase();        
                case 'No'
            end
        end        
    end 
    if (choice == 2)
        if (~exist('myDatabase','var'))
            fprintf('Please generate database first!\n');
        else
            recognition_rate = testsys(myDatabase,minmax);                
        end                        
    end 
 
    if (choice == 3)
        if (~exist('myDatabase','var'))
            fprintf('Please generate database first!\n');
        else            
            pause(0.1);            
            [file_name,file_path] = uigetfile ({'*.jpg';'*.pgm';'*.png'});
            if file_path ~= 0
                filename = [file_path,file_name];                
                facerecognition (filename,myDatabase,minmax);                        
            end
        end
    end
    if (choice == 4)
        clear all;
        close all;
        return;
    end    
end